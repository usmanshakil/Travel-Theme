<!DOCTYPE html>
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
<!-- Basic Page Needs -->
<meta charset="utf-8">
<title>Bed & Breakfast</title>
<meta name="description" content="Responsive Hotel  Site template">
<meta name="author" content="">
    <?php $plugin_path = plugins_url(); ?>
<!-- Mobile Specific Metas -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!-- CSS -->
<link rel="stylesheet" href="<?php echo $plugin_path; ?>/calender/css/base.css">
<link rel="stylesheet" href="<?php echo $plugin_path; ?>/calender/css/skeleton.css">
<link rel="stylesheet" href="<?php echo $plugin_path; ?>/calender/css/socialize-bookmarks.css">
<link rel="stylesheet" href="<?php echo $plugin_path; ?>/calender/css/layout.css">
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script type="text/javascript">
function delayedRedirect(){
    window.location = "<?php bloginfo('url');?>"
}
</script>
</head>
<body onLoad="setTimeout('delayedRedirect()', 5000)">
<?php
						$mail = $_POST['email'];
						$to = get_bloginfo('admin_email'); // Your email
						$subject = "Message from Your Site ";
						$headers = "From: Your Site <noreply@yourdomain.com>";
						$message = "Message\n";
						$message .= "\nName: " . sanitize_text_field($_POST['name']);
						$message .= "\nLast Name: " . sanitize_text_field($_POST['last_name']);
						$message .= "\nEmail: " . sanitize_email($_POST['email']);
						$message .= "\nPhone number: " . sanitize_text_field($_POST['phone_number']);
						$message .= "\nMessage: " . sanitize_text_field($_POST['message']);
						$sentOk = mail($to,$subject,$message,$headers);?>
<div class="container">
<div class="sixteen columns" style="text-align:center; padding-top:60px;">
 <p><img src="<?php echo $plugin_path; ?>/calender/images/ok.png" width="200" height="185" class="scale-with-grid"></p>
    <?php
    $options = get_option( 'calender_option' );
    $thank_type = $options['thank_type'];
    echo $thank_type;
    ?>
</div>
</div>
</body>
</html>