<!DOCTYPE html>
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
<!-- Basic Page Needs -->
<meta charset="utf-8">
<title>Bed & Breakfast</title>
<meta name="description" content="Simple and easy to edit Bed and Breakfast site template">
<meta name="author" content="">
<?php $plugin_path = plugins_url(); ?>
<!-- Mobile Specific Metas -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="<?php echo $plugin_path; ?>/calender/css/base.css">
    <link rel="stylesheet" href="<?php echo $plugin_path; ?>/calender/css/skeleton.css">
    <link rel="stylesheet" href="<?php echo $plugin_path; ?>/calender/css/layout.css">
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script type="text/javascript">
function delayedRedirect(){
    window.location = "<?php bloginfo('url');?>"}
</script>
</head>
<body onLoad="setTimeout('delayedRedirect()', 5000)">
<?php
       global $wpdb;
        if((!empty($_REQUEST['check_in'])) && (!empty($_REQUEST['check_out']))) {
           $check_in =  $_REQUEST['check_in'];
           $check_out = $_REQUEST['check_out'];
           $guest =  $_REQUEST['guest'];
           $rooms =  $_REQUEST['rooms'];
           $your_name =  sanitize_text_field($_REQUEST['name']);
           $lname =  sanitize_text_field($_REQUEST['last_name']);
           $email = sanitize_email($_REQUEST['email']);
           $ph_number = sanitize_text_field($_REQUEST['phone_number']);
           $ip_address = $_SERVER['REMOTE_ADDR'];
           $status = 0 ;
           $wpdb->insert(
                $wpdb->prefix.'bbcalender',
                array(
                'check_in' => $check_in,
                'check_out' => $check_out,
                'no_of_guest' => $guest,
                'room_type' => $rooms,
                'your_name' => $your_name,
                'last_name' => $lname,
                'email' => $email,
                'ph_number' => $ph_number,
                'ip_address' => $ip_address,
                'status' => $status
                 )); 
					    $mail = $_POST['email'];
						$to = get_bloginfo('admin_email');;  		// Your email
						$subject = "Request for avalilability";
						$headers = "From: Your site <noreply@yourdomain.com>";
						$message = "Message\n";
						$message .= "\nCheck in: " . $_POST['check_in'];
						$message .= "\nCheck out: " . $_POST['check_out'];
						$message .= "\nNumber of guest: " . $_POST['guest'];
						$message .= "\nNumber of rooms: " . $_POST['rooms'];
						$message .= "\nName: " . sanitize_text_field($_POST['name']);
						$message .= "\nName: " . sanitize_text_field($_POST['last_name']);
						$message .= "\nEmail: " . sanitize_email($_POST['email']);
						$message .= "\nPhone number: " . sanitize_text_field($_POST['phone_number']);
						//Receive Variable
						$sentOk = mail($to,$subject,$message,$headers);}?>
<div class="container">
<div class="sixteen columns" style="text-align:center; padding-top:60px;">
    <p><img src="<?php echo $plugin_path; ?>/calender/images/ok.png" width="200" height="185" class="scale-with-grid"></p>
    <?php
    $options = get_option( 'calender_option' );
    $thank_type = $options['thank_type'];
    echo $thank_type;
    ?>

</div>
</div>
</body>
</html>