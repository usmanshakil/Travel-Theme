<?php
/*
Plugin Name: Rooms Availability
Plugin URI: http://iintellect.co.uk/
Description: Bed & Breakfast calender plugin shows rooms availability, and notify the client using form data.
Version: 1.0
Author: HBK
Author URI: http://iintellect.co.uk/
License: GPLv2
*/
function bbreakfast_addStyles(){
    wp_register_style( 'datepicker', plugins_url( 'calender/css/datepicker.css' ) );
    wp_enqueue_style( 'datepicker' );
    wp_register_style( 'base', plugins_url( 'calender/css/base.css' ) );
    wp_enqueue_style( 'base' );}
function bbreakfast_addScripts(){
    // Register JavaScript.
    wp_register_script('jquery.ui.datepicker', plugins_url('js/jquery.ui.datepicker.js', __FILE__), array('jquery'));
    wp_register_script('jquery.ui.datepicker.min', plugins_url('js/jquery.ui.datepicker.min.js', __FILE__), array('jquery'));
	wp_register_script('jquery.validate', plugins_url('js/jquery.validate.js', __FILE__), array('jquery'));
	wp_register_script('cust-calender', plugins_url('js/cust-calender.js', __FILE__), array('jquery'));
	// Enqueue JavaScript.
    wp_enqueue_script('jquery.ui.datepicker');
	wp_enqueue_script('jquery.ui.datepicker.min');
	wp_enqueue_script('cust-calender');
    wp_enqueue_script('jquery.validate');}
function bbreakfast_admin_style() {
		wp_register_style( 'custom', plugins_url( 'calender/css/custom.css' ) );
		wp_enqueue_style( 'custom' );}
add_action('wp_enqueue_scripts','bbreakfast_addStyles');
add_action('wp_enqueue_scripts','bbreakfast_addScripts');
add_action( 'admin_enqueue_scripts', 'bbreakfast_admin_style' );		
	if((!empty($_REQUEST['check_in'])) && (!empty($_REQUEST['check_out']))) {
	include_once('availability.php'); }
    if(!empty($_REQUEST['gen_enq'])) {
        include_once('email-send.php');}
//Creating Shortcode
add_filter('mce_external_plugins', "calendar_register");
add_filter('mce_buttons', 'calendar_add_button', 0);
function calendar_add_button($buttons){
    array_push($buttons, "", "calendar");
    return $buttons; }
function calendar_register($plugin_array){
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/calender/js/calendar_shortcode.js";
    $plugin_array['calendar'] = $url;
    return $plugin_array; }
add_shortcode('availability','short_availability');
 function short_availability(){
   $options = get_option( 'calender_option' );
   $room_type = $options['room_type'];
   $arr_room_type = explode('|',$room_type);
   $no_of_guest =  $options['no_of_guest'];
   $arr_guest = explode('|',$no_of_guest);
    $plugin_path = plugins_url();
	ob_start();?>
    <ul class="tabs">
        <li><a class="active" href="#firstab-1"><?php _e('Check Availability',TEXTDOMAIN); ?></a></li>
        <li><a href="#firstab-2"><?php _e('General enquire',TEXTDOMAIN); ?></a></li>
    </ul>
    <ul class="tabs-content contact">
         <li class="active" id="firstab-1">
            <form action="" method="post" name="f1" id="availability-form">
                <fieldset>
                    <span><label><?php _e('Check in',TEXTDOMAIN); ?></label><input class="datepicker required calendar"  type="text" name="check_in" readonly></span>
                    <span><label><?php _e('Check out',TEXTDOMAIN); ?></label><input class="datepicker required calendar" type="text" name="check_out" readonly></span>
                    <br class="clear">
                </fieldset>
                <fieldset>
            <span>
                <label><?php _e('N°of guest',TEXTDOMAIN); ?></label>
                <select name="guest" class="required">
                    <option value=""><?php _e('- please select -',TEXTDOMAIN); ?></option>
                    <?php foreach($arr_guest as $ar_guest){
                        echo '<option>'.$ar_guest.'</option>'; }?>
                </select>
            </span>
            <span>
            <label><?php _e('Room type',TEXTDOMAIN); ?></label>
                <select name="rooms" class="required">
                    <option value=""><?php _e('- please select -',TEXTDOMAIN); ?></option>
                    <?php foreach($arr_room_type as $ar_room_type) {
                        echo '<option>'.$ar_room_type.'</option>'; } ?>
                </select>
            </span>
               <br class="clear">
                </fieldset>
                <fieldset>
                   <span><label><?php _e('Your Name',TEXTDOMAIN); ?></label><input type="text" name="name" class="required"/></span>
                    <span><label><?php _e('Your Last name',TEXTDOMAIN); ?></label><input type="text" name="last_name" class="required"/></span>
                    <br class="clear">
                </fieldset>
                <fieldset>
                    <span><label><?php _e('Your Email',TEXTDOMAIN); ?></label><input type="text" name="email" class="required email "></span>
                    <span><label><?php _e('Phone numbe',TEXTDOMAIN); ?>r</label><input type="text" name="phone_number" /></span>
                    <br class="clear">
                </fieldset>
                <button type="submit" class="button_4"><?php _e('Check availability',TEXTDOMAIN); ?></button>
            </form>
        </li>
        <li id="firstab-2">
            <form action="" method="post" id="contact-form">
                <fieldset>
                    <span><label><?php _e('Name',TEXTDOMAIN); ?></label><input name="name" class="required" type="text"/></span>
                    <span><label><?php _e('Last Name',TEXTDOMAIN); ?></label><input name="last_name" class="required " type="text"/></span>
                    <br class="clear">
                </fieldset>
                <fieldset>
                    <span><label> <?php _e('Email',TEXTDOMAIN); ?></label><input name="email" class="required email" type="email"/></span>
                    <span><label> <?php _e('Phone number',TEXTDOMAIN); ?></label><input name="phone number" type="text"/></span>
                </fieldset>
                <label style="margin-left:10px;"> <?php _e('Message',TEXTDOMAIN); ?> </label>
                <textarea name="message" class="required"></textarea>
                <input type="hidden" name="gen_enq" value="gen_enq"/>
                <button type="submit" class="button_4"><?php _e('Send Message',TEXTDOMAIN); ?></button>
            </form>
       </li>
    </ul>
<?php return ob_get_clean(); }
//Creating Database Table
global $jal_db_version;
$jal_db_version = "1.0";
function jal_install() {
    global $wpdb;
    global $jal_db_version;
    $table_name = $wpdb->prefix . "bbcalender";
    $sql = "CREATE TABLE $table_name (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      check_in VARCHAR(55)  NOT NULL,
      check_out VARCHAR(55)  NOT NULL,
      no_of_guest VARCHAR(55)  NOT NULL,
      room_type VARCHAR(100)  NOT NULL,
      your_name text NOT NULL,
      last_name text NOT NULL,
      email VARCHAR(100)  NOT NULL,
      ph_number VARCHAR(100)  NOT NULL,
      ip_address VARCHAR(100)  NOT NULL,
      status int NOT NULL,
      UNIQUE KEY id (id));";
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
    add_option( "jal_db_version", $jal_db_version ); }	
//Calling the functions for DataBase
register_activation_hook( __FILE__, 'jal_install' );
class calenderSettingsPage{
//Holds the values to be used in the fields callbacks
    private $options;
    public function __construct(){
    add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
    add_action( 'admin_init', array( $this, 'page_init' ) );}
 // Add options page
   public function add_plugin_page(){
         add_options_page(
            'Settings Admin',
            'Reservations',
            'manage_options',
            'calender-setting-admin',
            array( $this, 'create_admin_page' ));}
 // Options page callback
    public function create_admin_page() {
 // Set class property
        $this->options = get_option( 'calender_option' ); ?>
        <div class="wrap">
            <?php screen_icon(); ?>
            <h2>Booking Availability Settings</h2>
            <form method="post" action="options.php">
      <?php // This prints out all hidden setting fields
                settings_fields( 'calender_option_group' );
                do_settings_sections( 'calender-setting-admin' );
                submit_button();  ?>
            </form>
            <hr />
           <?php require_once('admin_data.php'); ?> 
        </div>
    <?php  }
// Register and add settings
    public function page_init(){
        register_setting(
            'calender_option_group', 
            'calender_option', 
            array( $this, 'sanitize' ));
        add_settings_section(
            'setting_section_id', 
            'Guests & Rooms Settings', 
            array( $this, 'print_section_info' ), 
            'calender-setting-admin');
        add_settings_field(
            'no_of_guest', 
            'No Of Guests', 
            array( $this, 'no_of_guest_callback' ), 
            'calender-setting-admin', 
            'setting_section_id' );
        add_settings_field(
            'room_type',
            'Type Of Rooms',
            array( $this, 'room_type_callback' ),
            'calender-setting-admin',
            'setting_section_id');
        add_settings_field(
            'thank_type',
            'Thank You Text',
            array( $this, 'thank_type_callback' ),
            'calender-setting-admin',
            'setting_section_id');}
 public function sanitize( $input ){
        $new_input = array();
        if( isset( $input['no_of_guest'] ) )
            $new_input['no_of_guest'] = sanitize_text_field( $input['no_of_guest'] );
        if( isset( $input['room_type'] ) )
            $new_input['room_type'] = sanitize_text_field( $input['room_type'] );
        if( isset( $input['thank_type'] ) )
             $new_input['thank_type'] = $input['thank_type'];
        return $new_input;}
 public function print_section_info(){
        print 'Enter your values separating by ( | ) below:';}
 public function no_of_guest_callback(){
        printf(
            '<input type="text" id="no_of_guest" size="40" placeholder=" e.g 0ne | Two | Three" name="calender_option[no_of_guest]" value="%s" />',
            isset( $this->options['no_of_guest'] ) ? esc_attr( $this->options['no_of_guest']) : ''
        );}
 public function room_type_callback(){
      printf(
            '<input type="text" id="room_type" size="40" placeholder=" e.g Single | Double | Cubic" name="calender_option[room_type]" value="%s" />',
            isset( $this->options['room_type'] ) ? esc_attr( $this->options['room_type']) : ''
        );}
 public function thank_type_callback(){
        printf(
            '<textarea id="thank_type" size="40" placeholder=" HTML Tags Supported.!" name="calender_option[thank_type]" >%s</textarea>',
            isset( $this->options['thank_type'] ) ? esc_attr( $this->options['thank_type']) : ''
        );}}
if( is_admin() )
    $calender_settings_page = new calenderSettingsPage();
	?>