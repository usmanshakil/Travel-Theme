//////////////////////////////////////////////////////////////////
// Add Calendar Shortcode
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.calendar', {

        init : function(ed, url){
            ed.addButton('calendar', {
                title : 'Calendar',
                onclick : function() {
                    ed.selection.setContent('[availability]');
                },
                image: url + "/calendar.png"
            });
        }
    });
    tinymce.PluginManager.add('calendar', tinymce.plugins.calendar);
})();