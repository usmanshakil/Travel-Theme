jQuery(document).ready(function() {
/*--------------------------------------------------------
Form validate and date
--------------------------------------------------------*/	  
jQuery("#availability-form").validate();
jQuery("#contact-form").validate();
jQuery(".datepicker").datepicker();

// MENU MOBILE ===============================================================================
 jQuery(document).ready(function(){
    
		//When btn is clicked
		jQuery(".btn-responsive-menu").click(function() {
			jQuery("#top-nav").slideToggle(400);
		
		});
    
    });
 });
