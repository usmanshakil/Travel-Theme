<?php global $wpdb; ?>
<?php
if(!empty($_REQUEST['adl'])){
    if($_REQUEST['adl'] == 'delete'){
    if(!empty($_REQUEST['mul_adl']))
    {
    $mul_adl = $_REQUEST['mul_adl'];
    foreach ($mul_adl as $mul_ad) {
          echo delete_booking_by_id($mul_ad);
        }
     }
    }
    if($_REQUEST['adl'] == 'approved'){
        if(!empty($_REQUEST['mul_adl']))
       {
            $mul_adl = $_REQUEST['mul_adl'];
            foreach ($mul_adl as $mul_ad) {
               echo update_booking_by_id($mul_ad);
			   echo email_by_id($mul_ad);
             }
        }
    }
    if($_REQUEST['adl'] == 'reject'){
        if(!empty($_REQUEST['mul_adl']))
        {
           $mul_adl = $_REQUEST['mul_adl'];
            foreach ($mul_adl as $mul_ad) {
                echo delete_booking_by_id($mul_ad);
            }
        }
    }
}?>
<h2>No. Of Bookings</h2>
 <small>Approve / Reject Bookings</small>
 <?php $allrecord = $wpdb->get_results('SELECT * FROM ' . $wpdb->base_prefix . 'bbcalender');    ?>
 		<form action="" method="post">
            <table border="1" width="100%">
                <tr>
                    <th><select name="adl">
                        <option value="">Bulk Action</option>
                        <option value="approved">Approved</option>
                        <option value="reject">Reject</option>
                       <option value="delete">Delete</option>
                    </select><input type="submit" class="bb_app" value="Apply"/> </th>
                    <th>Check In</th>
                    <th>Check Out</th>
                    <th>N°of guest</th>
                    <th>Room type</th>
                    <th>Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Status</th>
                </tr>
        <?php   if($allrecord){
                foreach($allrecord as $allrec) {?>
                <tr>
                   <td><input type="checkbox" name="mul_adl[]" value="<?php echo $allrec->id; ?>" /> </td>
                    <td><?php echo $allrec->check_in; ?></td>
                   <td><?php echo $allrec->check_out; ?> </td>
                    <td><?php echo $allrec->no_of_guest; ?></td>
                    <td><?php echo $allrec->room_type; ?></td>
                    <td><?php echo $allrec->your_name; ?></td>
                    <td><?php echo $allrec->last_name; ?></td>
                    <td><?php echo $allrec->email; ?></td>
                    <td><?php echo $allrec->ph_number; ?></td>
                   <td><?php if($allrec->status == 0 ) { echo 'Not Approved.!';} else { echo 'Approved.!';}?></td>
                 </tr>
               <?php } }
                else { ?>
                <tr>
                <td> No Record Found.!</td>
                   </tr>
                <?php }?>
              </table>
              </form>
<?php   function update_booking_by_id($id){
        global $wpdb;
        $status = 1;
        $wpdb->update(
            $wpdb->base_prefix.'bbcalender',
            array(
                'status' => $status
                 ),
            array( 'id' => $id )
        );
    }
    function delete_booking_by_id($id){
        global $wpdb;
        $wpdb->delete(
            $wpdb->base_prefix.'bbcalender',
            array( 'id' => $id )
        );
    }
	function email_by_id($id){
		global $wpdb;
		$allrecord = $wpdb->get_results('SELECT * FROM ' . $wpdb->base_prefix . 'bbcalender WHERE id ='. $id .'');
		foreach($allrecord as $allrec) {
						$mail = $allrec->email;
						$to = $allrec->email;  		// Your email
						$subject = "Confirmation of avalilability";
						$headers = "From: Your site <noreply@yourdomain.com>";
						$message = "Message\n";
						$message .= "\nCheck in: " . $allrec->check_in;
						$message .= "\nCheck out: " . $allrec->check_out;
						$message .= "\nNumber of guest: " . $allrec->no_of_guest;
						$message .= "\nNumber of rooms: " . $allrec->room_type;
						$message .= "\nName: " . $allrec->your_name;
						$message .= "\nName: " . $allrec->last_name;
						$message .= "\nEmail: " . $allrec->email;
						$message .= "\nPhone number: " . $allrec->ph_number;
						//Receive Variable
						$sentOk = mail($to,$subject,$message,$headers);
			}}?>