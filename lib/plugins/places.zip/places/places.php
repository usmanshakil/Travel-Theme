<?php
/*
Plugin Name: Places & Accomodation
Plugin URI: http://iintellect.co.uk/
Description: Bed & Breakfast Section Plugin is used to create simple places with multiple images.
Version: 1.0
Author: HBK
Author URI: http://iintellect.co.uk/
License: GPLv2
*/
?>
<?php
function bbreakfast_placeScripts(){
    // Register JavaScript.
    wp_register_script('jquery.jcarousel.min', plugins_url('js/jquery.jcarousel.min.js', __FILE__), array('jquery'));
	wp_register_script('flexi_slider', plugins_url('js/flexi_slider.js', __FILE__), array('jquery'));
	wp_register_script('cust-places', plugins_url('js/cust-places.js', __FILE__), array('jquery'));
    // Enqueue JavaScript.
    wp_enqueue_script('jquery.jcarousel.min');
	wp_enqueue_script('cust-places');
	wp_enqueue_script('flexi_slider');}
add_action('wp_enqueue_scripts','bbreakfast_placeScripts');
//Creating shortcode
add_filter('mce_external_plugins', "places_register");
add_filter('mce_buttons', 'places_add_button', 0);
function places_add_button($buttons)
{
    array_push($buttons, "", "places");
    return $buttons;
}
function places_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/places/js/places_shortcode.js";
    $plugin_array['places'] = $url;
    return $plugin_array;
}
add_shortcode('places','short_places');
function short_places() {
    ob_start();
    $places = array( 'post_type' => 'places', );
    $places_loop = new WP_Query($places);
    ?>
    <div class="mycont">
        <ul class="mycarousel">
            <?php while ( $places_loop->have_posts() ) : $places_loop->the_post();?>
                <?php     $feat_image = wp_get_attachment_url( get_post_thumbnail_id() ); ?>
                <li class="item">
                    <figure><a href="<?php echo $feat_image; ?>"><div class="icon-hover" ></div><?php the_post_thumbnail(); ?></a></figure>
                    <div class="spacer-2">
                        <h3><?php the_title(); ?> <span><?php echo esc_html( get_post_meta( get_the_ID(), 'text_under_title', true ) ); ?></span></h3>
                        <?php the_content();?>
                    </div>
                </li>
            <?php endwhile; ?>
        </ul>
    </div>
    <?php
    return ob_get_clean();
}
// Creating Places CPT
function bbreakfast_places() {
    register_post_type( 'places',
        array(
            'labels' => array(
                'name' => 'Places',
                'singular_name' => 'Places',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Place',
                'edit' => 'Edit',
                'edit_item' => 'Edit Places',
                'new_item' => 'New Place',
                'view' => 'View',
                'view_item' => 'View Place',
                'search_items' => 'Search Places',
                'not_found' => 'No Places found',
                'not_found_in_trash' => 'No Places found in Trash',
                'parent' => 'Parent Places'
				),
	 
				'public' => true,
				'menu_position' => 16,
				'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields' ),
				'taxonomies' => array( '' ),
				'menu_icon' => plugins_url( 'images/places.png', __FILE__ ),
				'has_archive' => true
			)
   		 );
	} 
add_action( 'init', 'bbreakfast_places' );
// Registering the Custom Function For Meta Box
add_action( 'admin_init', 'bb_text_under_title' );
function bb_text_under_title() {
   		 add_meta_box( 'text_under_title_meta_box',
			'Text under Title',
			'display_text_under_title_meta_box',
			'places', 'normal', 'high'
		);
	}
function display_text_under_title_meta_box( $TextunderTitle ) {
// Retrieve current name of the Testimonial Author Name by Testimonial ID
    $text_under_title = esc_html( get_post_meta( $TextunderTitle->ID, 'text_under_title', true ) );
    ?>
    <table>
        <tr>
            <td style="width: 100%">Text Under Title</td>
            <td><input type="text" size="80" name="txt_under_title" value="<?php echo $text_under_title; ?>" /></td>
        </tr>
       </table>
    <?php
}
add_action( 'save_post', 'add_text_under_title_fields', 10, 2 );
function add_text_under_title_fields( $text_under_title_id, $TextunderTitle ) {
    // Check post type for Testimonial Author
    if ( $TextunderTitle->post_type == 'places' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['txt_under_title'] ) && $_POST['txt_under_title'] != '' ) {
            update_post_meta( $text_under_title_id, 'text_under_title', $_POST['txt_under_title'] );
        }
        
    }
}
?>