jQuery(document).ready(function() {
/*--------------------------------------------------------
Flexslider
--------------------------------------------------------*/
jQuery(window).load(function() {
			jQuery('.flexslider').flexslider();
		});		
/*--------------------------------------------------------
Carousel
--------------------------------------------------------*/	
jQuery(document).ready(function() {
    jQuery('.mycarousel').jcarousel({
        scroll:1,
        wrap: 'circular'
    });
});
});