//////////////////////////////////////////////////////////////////
// Add Places Shortcode
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.places', {

        init : function(ed, url){
            ed.addButton('places', {
                title : 'Places',
                onclick : function() {
                    ed.selection.setContent('[places]');
                },
                image: url + "/places.png"
            });
        }
    });

    tinymce.PluginManager.add('places', tinymce.plugins.places);
})();