<?php
/*
Plugin Name: Rooms
Plugin URI: http://iintellect.co.uk/
Description: Bed & Breakfast Section Plugin is used to create simple rooms with multiple images and rooms facility icons.
Version: 1.0
Author: HBK
Author URI: http://iintellect.co.uk/
License: GPLv2
*/
//Creating Shortcode
add_filter('mce_external_plugins', "rooms_register");
add_filter('mce_buttons', 'rooms_add_button', 0);
function rooms_add_button($buttons)
{
    array_push($buttons, "", "rooms");
    return $buttons;
}
function rooms_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/rooms/js/rooms_shortcode.js";
    $plugin_array['rooms'] = $url;
    return $plugin_array;
}
add_shortcode('rooms','short_rooms');
function short_rooms() {
    ob_start(); ?>
    <?php
    $rooms = array( 'post_type' => 'rooms', );
    $rooms_loop = new WP_Query($rooms);
    $room_color = 1;
    while ( $rooms_loop->have_posts() ) : $rooms_loop->the_post();
        if($room_color == 4){
            $room_color = 1;
        }
        $room_package = esc_html( get_post_meta( get_the_ID(), 'room_package', true ) );
        $room_price = esc_html( get_post_meta( get_the_ID(), 'room_price', true ) );
        $room_currency = esc_html( get_post_meta( get_the_ID(), 'room_currency', true ) );
        $room_img1 = esc_html( get_post_meta( get_the_ID(), 'room_img1', true ) );
        $room_img_desc1 = esc_html( get_post_meta( get_the_ID(), 'room_img_desc1', true ) );
        $room_img2 = esc_html( get_post_meta( get_the_ID(), 'room_img2', true ) );
        $room_img_desc2 = esc_html( get_post_meta( get_the_ID(), 'room_img_desc2', true ) );
        $room_img3 = esc_html( get_post_meta( get_the_ID(), 'room_img3', true ) );
        $room_img_desc3 = esc_html( get_post_meta( get_the_ID(), 'room_img_desc3', true ) );
        $max_occupancy = esc_html( get_post_meta( get_the_ID(), 'max_occupancy', true ) );
        $lcd_tv = esc_html( get_post_meta( get_the_ID(), 'lcd_tv', true ) );
        $wifi = esc_html( get_post_meta( get_the_ID(), 'wifi', true ) );
        $breakfast = esc_html( get_post_meta( get_the_ID(), 'breakfast', true ) );
        $air_warm = esc_html( get_post_meta( get_the_ID(), 'air_warm', true ) );
        $air_cold = esc_html( get_post_meta( get_the_ID(), 'air_cold', true ) );
        $pet = esc_html( get_post_meta( get_the_ID(), 'pet', true ) );
        $dinner = esc_html( get_post_meta( get_the_ID(), 'dinner', true ) );
        $safe_deposit = esc_html( get_post_meta( get_the_ID(), 'safe_deposit', true ) );
        $loundry = esc_html( get_post_meta( get_the_ID(), 'loundry', true ) );
        $parking = esc_html( get_post_meta( get_the_ID(), 'parking', true ) );
        $swimming = esc_html( get_post_meta( get_the_ID(), 'swimming', true ) );
        $master_bath = esc_html( get_post_meta( get_the_ID(), 'master_bath', true ) );
        ?>
        <article class="clearfix rooms-clearfix">
            <div class="seven columns alpha">
                <div class="flexslider">
                    <ul class="slides">
                        <?php if(!empty($room_img1)) {?>
                            <li><figure><a href="<?php echo $room_img1; ?>"><div class="icon-hover" ></div><img src="<?php echo $room_img1; ?> " alt=""></a></figure><p class="flex-caption"><?php echo $room_img_desc1; ?></p></li>
                        <?php }
                        if(!empty($room_img2)){
                            ?>
                            <li><figure><a href="<?php echo $room_img2; ?>"><div class="icon-hover" ></div><img src="<?php echo $room_img2; ?> " alt=""></a></figure><p class="flex-caption"><?php echo $room_img_desc2; ?></p></li>
                        <?php }
                        if(!empty($room_img3)) {
                            ?>
                            <li><figure><a href="<?php echo $room_img3; ?>"><div class="icon-hover" ></div><img src="<?php echo $room_img3; ?> " alt=""></a></figure><p class="flex-caption"><?php echo $room_img_desc3; ?></p></li>
                        <?php } ?>
                    </ul>
                    <span class="<?php if($room_color == 1) { echo 'price-green';} elseif ($room_color == 2) { echo 'price-aqua';} elseif($room_color == 3) { echo 'price-blue';} else { echo 'price-green';}?>"><?php echo $room_price; ?><small><?php echo $room_currency; ?></small><em><?php if(!empty($room_package)){ echo $room_package; } else { echo 'per night'; } ?></em></span> </div><!-- end flexi-->
            </div>
            <div class="nine columns omega">
                <div class="spacer-3">
                    <h3><?php the_title(); ?></h3>
                    <?php the_content(); ?>
                    <ul class="room_facilities">
                        <?php if(!empty($max_occupancy)){ ?>
                            <li class="occupancy"><a class="tooltip_1" href="#" title="<?php echo $max_occupancy; ?>"><?php echo $max_occupancy; ?></a></li>
                        <?php }
                        if(!empty($lcd_tv)){
                            ?>
                            <li class="lcd"><a class="tooltip_1"  href="#" title="<?php echo $lcd_tv;?>"><?php echo $lcd_tv;?></a></li>
                        <?php }
                        if(!empty($wifi)){
                            ?>
                            <li class="wifi"><a class="tooltip_1" href="#" title="<?php echo $wifi; ?>"><?php echo $wifi; ?></a></li>
                        <?php }
                        if(!empty($breakfast)){
                            ?>
                            <li class="breakfast"><a class="tooltip_1" href="#" title="<?php echo $breakfast; ?>"><?php echo $breakfast; ?></a></li>
                        <?php }
                        if(!empty($air_warm)){
                            ?>
                            <li class="air-warm"><a class="tooltip_1" href="#" title="<?php echo $air_warm; ?>"><?php echo $air_warm; ?></a></li>
                        <?php }
                        if(!empty($air_cold)){
                            ?>
                            <li class="air-cold"><a class="tooltip_1" href="#" title="<?php $air_cold; ?>"><?php $air_cold; ?></a></li>
                        <?php }
                        if(!empty($pet)){
                            ?>
                            <li class="pet"><a class="tooltip_1" href="#" title="<?php echo $pet; ?>"><?php echo $pet; ?></a></li>
                        <?php }
                        if(!empty($dinner)){
                            ?>
                            <li class="dinner"><a class="tooltip_1" href="#" title="<?php echo $dinner; ?>"><?php echo $dinner; ?></a></li>
                        <?php }
                        if(!empty($safe_deposit)) {
                            ?>
                            <li class="safe"><a class="tooltip_1" href="#" title="<?php echo $safe_deposit; ?>"><?php echo $safe_deposit; ?></a></li>
                        <?php }
                        if(!empty($swimming)) {
                            ?>
                            <li class="swimming"><a class="tooltip_1" href="#" title="<?php echo $swimming; ?>"><?php echo $swimming; ?></a></li>
                        <?php }
                        if(!empty($loundry)) {
                            ?>
                            <li class="loundry"><a class="tooltip_1" href="#" title="<?php echo $loundry; ?>"><?php echo $loundry; ?></a></li>
                        <?php }
                        if(!empty($parking)) {
                            ?>
                            <li class="parking"><a class="tooltip_1" href="#" title="<?php echo $parking; ?>"><?php echo $parking; ?></a></li>
                        <?php }
                        if(!empty($master_bath)){
                            ?>
                            <li class="bath"><a class="tooltip_1" href="#" title="<?php echo $master_bath; ?>"><?php echo $master_bath; ?></a></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </article>
        <?php
        $room_color ++;
    endwhile; ?>
    <?php
    return ob_get_clean();
}
add_action( 'init', 'bbreakfast_rooms' );
function bbreakfast_rooms() {
    register_post_type( 'rooms',
        array(
            'labels' => array(
                'name' => 'Rooms',
                'singular_name' => 'Room',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New New Room',
                'edit' => 'Edit',
                'edit_item' => 'Edit Room',
                'new_item' => 'New Room',
                'view' => 'View',
                'view_item' => 'View Room',
                'search_items' => 'Search Rooms',
                'not_found' => 'No Rooms found',
                'not_found_in_trash' => 'No Rooms found in Trash',
                'parent' => 'Parent Room'
            ),
 
            'public' => true,
            'menu_position' => 17,
            'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields' ),
            'taxonomies' => array( '' ),
            'menu_icon' => plugins_url( 'images/rooms.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
//Registering the Rooms Details Function
add_action( 'admin_init', 'bb_meta_box' );
//Implementation of the Rooms Details Function
function bb_meta_box() {
    add_meta_box( 'rooms_meta_box',
        'Room Details',
        'display_rooms_meta_box',
        'rooms', 'normal', 'high'
    );
}
//Implementation of the display_rooms_meta_box Function
function display_rooms_meta_box( $room ) {
    // Retrieve current name  based on ID
    $room_price = esc_html( get_post_meta( $room->ID, 'room_price', true ) );
    $room_currency = esc_html( get_post_meta( $room->ID, 'room_currency', true ) );
	$room_img1 = esc_html( get_post_meta( $room->ID, 'room_img1', true ) );
	$room_img_desc1 = esc_html( get_post_meta( $room->ID, 'room_img_desc1', true ) );
	$room_img2 = esc_html( get_post_meta( $room->ID, 'room_img2', true ) );
	$room_img_desc2 = esc_html( get_post_meta( $room->ID, 'room_img_desc2', true ) );
	$room_img3 = esc_html( get_post_meta( $room->ID, 'room_img3', true ) );
	$room_img_desc3 = esc_html( get_post_meta( $room->ID, 'room_img_desc3', true ) );
	$room_package = esc_html( get_post_meta( $room->ID, 'room_package', true ) );
    ?>
    <table>
        <tr>
            <td style="width: 100%">Room Package</td>
            <td><input type="text" size="80" name="room_package" placeholder="e.g Per Night " value="<?php echo $room_package; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 100%">Room Price</td>
            <td><input type="text" size="80" name="room_price" placeholder="e.g 19.00 " value="<?php echo $room_price; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 150px">Enter Your Currency Symbol</td>
            <td><input type="text" size="80" name="room_currency" placeholder=" e.g $ " value="<?php echo $room_currency; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 150px">Enter 1st Image Path</td>
            <td><input type="text" size="80" name="room_img1" placeholder="Reccomended dimension 550px * 400px" value="<?php echo $room_img1; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 150px">Enter 1st Image Short Description</td>
            <td><input type="text" size="80" name="room_img_desc1" placeholder="Image Short Description" value="<?php echo $room_img_desc1; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 150px">Enter 2nd Image Path</td>
            <td><input type="text" size="80" name="room_img2" placeholder="Reccomended dimension 550px * 400px" value="<?php echo $room_img2; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 150px">Enter 2nd Image Short Description</td>
            <td><input type="text" size="80" name="room_img_desc2" placeholder="Image Short Description" value="<?php echo $room_img_desc2; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 150px">Enter 3rd Image Path</td>
            <td><input type="text" size="80" name="room_img3" placeholder="Reccomended dimension 550px * 400px" value="<?php echo $room_img3; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 150px">Enter 3rd Image Short Description</td>
            <td><input type="text" size="80" name="room_img_desc3" placeholder="Image Short Description" value="<?php echo $room_img_desc3; ?>" /></td>
        </tr>
    </table>
    <?php
}
//Registering the Room Facilities Function
add_action( 'admin_init', 'bb_facilities_meta_box' );
//Implementation of the Room Facilities Function
function bb_facilities_meta_box() {
    add_meta_box( 'facilities_meta_box',
        'Room Facilities',
        'display_facilities_meta_box',
        'rooms', 'normal', 'high'
    );
}
//Implementation of the display_facilities_meta_box Function
function display_facilities_meta_box( $facility ) {
    // Retrieve current name  based on ID
    $max_occupancy = esc_html( get_post_meta( $facility->ID, 'max_occupancy', true ) );
    $lcd_tv = esc_html( get_post_meta( $facility->ID, 'lcd_tv', true ) );
    $wifi = esc_html( get_post_meta( $facility->ID, 'wifi', true ) );
    $breakfast = esc_html( get_post_meta( $facility->ID, 'breakfast', true ) );
    $air_warm = esc_html( get_post_meta( $facility->ID, 'air_warm', true ) );
    $air_cold = esc_html( get_post_meta( $facility->ID, 'air_cold', true ) );
    $pet = esc_html( get_post_meta( $facility->ID, 'pet', true ) );
    $dinner = esc_html( get_post_meta( $facility->ID, 'dinner', true ) );
    $safe_deposit = esc_html( get_post_meta( $facility->ID, 'safe_deposit', true ) );
    $loundry = esc_html( get_post_meta( $facility->ID, 'loundry', true ) );
    $parking = esc_html( get_post_meta( $facility->ID, 'parking', true ) );
    $swimming = esc_html( get_post_meta( $facility->ID, 'swimming', true ) );
    $master_bath = esc_html( get_post_meta( $facility->ID, 'master_bath', true ) );
    ?>
    <table>
        <tr>
            <td style="width: 100%">Max occupancy <input type="text" size="50" name="max_occupancy" placeholder="Leave Empty If Not Required" value="<?php echo $max_occupancy; ?>" /></td>
            <td style="width: 100%">LCD TV <input type="text" size="40" name="lcd_tv" placeholder="Leave Empty If Not Required" value="<?php echo $lcd_tv; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 100%">Breakfast included <input type="text" size="50" name="breakfast" placeholder="Leave Empty If Not Required" value="<?php echo $breakfast; ?>" /></td>
            <td style="width: 100%">Air condition warm<input type="text" size="40" name="air_warm" placeholder="Leave Empty If Not Required" value="<?php echo $air_warm; ?>" /></td>
            
        </tr>
        <tr>
            <td style="width: 100%">Pet allowed<input type="text" size="50" name="pet" placeholder="Leave Empty If Not Required" value="<?php echo $pet; ?>" /></td>
            <td style="width: 100%">Dinner included<input type="text" size="40" name="dinner" placeholder="Leave Empty If Not Required" value="<?php echo $dinner; ?>" /></td>
            
        </tr>
        <tr>
            <td style="width: 100%">Loundry service<input type="text" size="50" name="loundry" placeholder="Leave Empty If Not Required" value="<?php echo $loundry; ?>" /></td>
            <td style="width: 100%">Parking<input type="text" size="40" name="parking" placeholder="Leave Empty If Not Required" value="<?php echo $parking; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 100%">Large master bathroom<input type="text" size="50" name="master_bath" placeholder="Leave Empty If Not Required" value="<?php echo $master_bath; ?>" /></td>
           <td style="width: 100%">Swimming poll<input type="text" size="40" name="swimming" placeholder="Leave Empty If Not Required" value="<?php echo $swimming; ?>" /></td> 
         </tr>
         <tr>
         <td style="width: 100%">Wifi broadband access <input type="text" size="50" name="wifi" placeholder="Leave Empty If Not Required" value="<?php echo $wifi; ?>" /></td>
         <td style="width: 100%">Air condition cold<input type="text" size="40" name="air_cold" placeholder="Leave Empty If Not Required" value="<?php echo $air_cold; ?>" /></td>
         
         </tr>
         <tr>
         <td style="width: 100%">Safe-deposit box<input type="text" size="50" name="safe_deposit" placeholder="Leave Empty If Not Required" value="<?php echo $safe_deposit; ?>" /></td>
         </tr>
    </table>
<?php
}
//Registering a Save Post Function
add_action( 'save_post', 'add_rooms_fields', 10, 2 );
function add_rooms_fields( $rooms_id, $room ) {
    // Check post type for movie reviews
    if ( $room->post_type == 'rooms' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['room_package'] )  ) {
            update_post_meta( $rooms_id, 'room_package', $_POST['room_package'] );
        }
        if ( isset( $_POST['room_price'] )  ) {
            update_post_meta( $rooms_id, 'room_price', $_POST['room_price'] );
        }
        if ( isset( $_POST['room_currency'] )  ) {
            update_post_meta( $rooms_id, 'room_currency', $_POST['room_currency'] );
        }
		if ( isset( $_POST['room_img1'] )  ) {
            update_post_meta( $rooms_id, 'room_img1', $_POST['room_img1'] );
        }
		if ( isset( $_POST['room_img_desc1'] )  ) {
            update_post_meta( $rooms_id, 'room_img_desc1', $_POST['room_img_desc1'] );
        }
		if ( isset( $_POST['room_img2'] )  ) {
            update_post_meta( $rooms_id, 'room_img2', $_POST['room_img2'] );
        }
		if ( isset( $_POST['room_img_desc2'] )  ) {
            update_post_meta( $rooms_id, 'room_img_desc2', $_POST['room_img_desc2'] );
        }
		if ( isset( $_POST['room_img3'] )  ) {
            update_post_meta( $rooms_id, 'room_img3', $_POST['room_img3'] );
        }
		if ( isset( $_POST['room_img_desc3'] ) && $_POST['room_img_desc3'] != '' ) {
            update_post_meta( $rooms_id, 'room_img_desc3', $_POST['room_img_desc3'] );
        }
    }
}
//Registering a Save Post Function
add_action( 'save_post', 'add_facilities_fields', 10, 2 );
function add_facilities_fields( $facilities_id, $facility ) {
    // Check post type for movie reviews
    if ( $facility->post_type == 'rooms' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['max_occupancy'] ) ) {
            update_post_meta( $facilities_id, 'max_occupancy', $_POST['max_occupancy'] );
        }
        if ( isset( $_POST['lcd_tv'] )  ) {
            update_post_meta( $facilities_id, 'lcd_tv', $_POST['lcd_tv'] );
        }
        if ( isset( $_POST['wifi'] ) ) {
            update_post_meta( $facilities_id, 'wifi', $_POST['wifi'] );
        }
        if ( isset( $_POST['breakfast'] ) ) {
            update_post_meta( $facilities_id, 'breakfast', $_POST['breakfast'] );
        }
        if ( isset( $_POST['air_warm'] )  ) {
            update_post_meta( $facilities_id, 'air_warm', $_POST['air_warm'] );
        }
        if ( isset( $_POST['air_cold'] ) ) {
            update_post_meta( $facilities_id, 'air_cold', $_POST['air_cold'] );
        }
        if ( isset( $_POST['pet'] )  ) {
            update_post_meta( $facilities_id, 'pet', $_POST['pet'] );
        }
        if ( isset( $_POST['dinner'] )  ) {
            update_post_meta( $facilities_id, 'dinner', $_POST['dinner'] );
        }
        if ( isset( $_POST['safe_deposit'] )  ) {
            update_post_meta( $facilities_id, 'safe_deposit', $_POST['safe_deposit'] );
        }
        if ( isset( $_POST['loundry'] )  ) {
            update_post_meta( $facilities_id, 'loundry', $_POST['loundry'] );
        }
        if ( isset( $_POST['parking'] )  ) {
            update_post_meta( $facilities_id, 'parking', $_POST['parking'] );
        }
        if ( isset( $_POST['swimming'] )  ) {
            update_post_meta( $facilities_id, 'swimming', $_POST['swimming'] );
        }
        if ( isset( $_POST['master_bath'] )  ) {
            update_post_meta( $facilities_id, 'master_bath', $_POST['master_bath'] );
        }
    }
}
?>