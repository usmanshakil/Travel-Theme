//////////////////////////////////////////////////////////////////
// Add Rooms Shortcode
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.rooms', {

        init : function(ed, url){
            ed.addButton('rooms', {
                title : 'Rooms',
                onclick : function() {
                    ed.selection.setContent('[rooms]');
                },
                image: url + "/rooms.png"
            });
        }
    });
    tinymce.PluginManager.add('rooms', tinymce.plugins.rooms);
})();