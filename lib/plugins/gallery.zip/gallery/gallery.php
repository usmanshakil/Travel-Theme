<?php
/*
Plugin Name: Image Gallery
Plugin URI: http://iintellect.co.uk/
Description: Bed & Breakfast Gallery plugin is used to create Full Width images gallery with simple caption text.
Version: 1.0
Author: HBK
Author URI: http://iintellect.co.uk/
License: GPLv2
*/
?>
<?php
// Gallery Shortcode
add_filter('mce_external_plugins', "gallery_register");
add_filter('mce_buttons', 'gallery_add_button', 0);
function gallery_add_button($buttons)
{
    array_push($buttons, "", "gallery");
    return $buttons;
}
function gallery_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/gallery/js/gallery_shortcode.js";
    $plugin_array['gallery'] = $url;
    return $plugin_array;
}
add_shortcode('bbgal','short_gallery');
function short_gallery($atts) {
    $plugin_path = plugins_url();
    ob_start();
    extract( shortcode_atts( array(
        'galid' => '#',
        ), $atts ) );
    ?>
    <span class="gallery-bt"><a href="?page_id=<?php echo $atts['galid']; ?>"><img src="<?php echo $plugin_path; ?>/gallery/images/fullscreen-button.png" width="213" height="152" alt=""></a></span>
    <?php return ob_get_clean();
}
// Creating Gallery CPT
function bbreakfast_galleries() {
    register_post_type( 'galleries',
        array(
            'labels' => array(
                'name' => 'Gallery',
                'singular_name' => 'Gallery Images',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Image',
                'edit' => 'Edit',
                'edit_item' => 'Edit Image',
                'new_item' => 'New Image',
                'view' => 'View',
                'view_item' => 'View Image',
                'search_items' => 'Search Images',
                'not_found' => 'No Images found',
                'not_found_in_trash' => 'No Images found in Trash',
                'parent' => 'Parent Images'
            ),
            'public' => true,
            'menu_position' => 16,
            'supports' => array( 'title', 'thumbnail'),
            'taxonomies' => array( '' ),
            'menu_icon' => plugins_url( 'images/gallery.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
add_action( 'init', 'bbreakfast_galleries' );
// Registering the Custom Function For Meta Box
add_action( 'admin_init', 'bb_gallery_caption' );
function bb_gallery_caption() {
    add_meta_box( 'gallery_caption_meta_box',
        'Gallery Caption',
        'display_gallery_caption_meta_box',
        'galleries', 'normal', 'high'
    );
}
function display_gallery_caption_meta_box( $gallerycaption ) {
// Retrieve current Gallery caption ID
    $gallerycaption = esc_html( get_post_meta( $gallerycaption->ID, 'gallerycaption', true ) );
    ?>
    <table>
        <tr>
            <td style="width: 100%">Gallery Caption</td>
            <td><input type="text" size="80" name="gallerycaption" value="<?php echo $gallerycaption; ?>" /></td>
        </tr>
    </table>
<?php
}
add_action( 'save_post', 'add_gallery_caption_fields', 10, 2 );
function add_gallery_caption_fields( $gallery_caption_id, $gallerycaption ) {
    // Check post type for Gallery Caption
    if ( $gallerycaption->post_type == 'galleries' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['gallerycaption'] )) {
            update_post_meta( $gallery_caption_id, 'gallerycaption', $_POST['gallerycaption'] );
        }
    }
}
?>