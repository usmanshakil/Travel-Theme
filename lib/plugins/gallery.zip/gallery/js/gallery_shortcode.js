//////////////////////////////////////////////////////////////////
// Add Gallery Shortcode
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.gallery', {

        init : function(ed, url){
            ed.addButton('gallery', {
                title : 'Image Gallery',
                onclick : function() {
                    ed.selection.setContent('[bbgal galid="Your Gallery Page ID e.g 38"]');
                },
                image: url + "/gallery.png"
            });
        }
    });

    tinymce.PluginManager.add('gallery', tinymce.plugins.gallery);
})();