<?php
/*
Plugin Name: Bed & Breakfast Testimonials
Plugin URI: http://iintellect.co.uk/
Description: Bed & Breakfast Testimonials plugin add simple testimonial scroller with author basic info.
Version: 1.0
Author: HBK
Author URI: http://iintellect.co.uk/
License: GPLv2
*/
?>
<?php
function bbreakfast_tesScripts(){
    // Register JavaScript.
    wp_register_script('quotes.min', plugins_url('js/quotes.min.js', __FILE__), array('jquery'));
	wp_register_script('cust-test', plugins_url('js/cust-test.js', __FILE__), array('jquery'));
    // Enqueue JavaScript.
    wp_enqueue_script('quotes.min');
	wp_enqueue_script('cust-test');}
add_action('wp_enqueue_scripts','bbreakfast_tesScripts');	
//Creating Shortcode
add_filter('mce_external_plugins', "testimonials_register");
add_filter('mce_buttons', 'testimonials_add_button', 0);
function testimonials_add_button($buttons)
{
    array_push($buttons, "", "testimonials");
    return $buttons;
}
function testimonials_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbtestimonials/js/testimonials_shortcode.js";
    $plugin_array['testimonials'] = $url;
    return $plugin_array;
}
add_shortcode('testimonials','short_testimonials');
function short_testimonials($atts) {
    extract( shortcode_atts( array(
        'limit' => 1,
    ), $atts ) );
    if(empty($atts['limit'])) {
        $atts['limit'] = -1;
    }
    ob_start(); ?>
    <article class="twelve columns offset-by-two" >
     <?php
    $testimonial = array( 'post_type' => 'testimonials','posts_per_page' => $atts['limit'] );
    $testimonial_loop = new WP_Query($testimonial);
    ?>
      <div id="testimonials">
          <ul >
              <?php while ( $testimonial_loop->have_posts() ) : $testimonial_loop->the_post();?>
                  <li><blockquote><?php the_content();?></blockquote><cite>by <?php echo esc_html( get_post_meta( get_the_ID(), 'testimonial_author', true ) ); ?></cite> </li>
              <?php endwhile; ?>
          </ul>
      </div>
    </article>
    <br class="clear">
    <?php
    return ob_get_clean();
}
// Creating Testimonials CPT
function bbreakfast_testimonials() {
    register_post_type( 'testimonials',
        array(
            'labels' => array(
                'name' => 'Testimonials',
                'singular_name' => 'Testimonials',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Testimonial',
                'edit' => 'Edit',
                'edit_item' => 'Edit Testimonial',
                'new_item' => 'New Testimonial',
                'view' => 'View',
                'view_item' => 'View Testimonial',
                'search_items' => 'Search Testimonials',
                'not_found' => 'No Testimonial found',
                'not_found_in_trash' => 'No Testimonial found in Trash',
                'parent' => 'Parent Testimonial'
				),
	 
				'public' => true,
				'menu_position' => 15,
				'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields' ),
				'taxonomies' => array( '' ),
				'menu_icon' => plugins_url( 'images/testimonial.png', __FILE__ ),
				'has_archive' => true
			)
   		 );
	} 
add_action( 'init', 'bbreakfast_testimonials' );
// Registering the Custom Function For Meta Box
add_action( 'admin_init', 'bb_by' );
function bb_by() {
   		 add_meta_box( 'testimonial_meta_box',
			'Testimonial Author',
			'display_testimonial_meta_box',
			'testimonials', 'normal', 'high'
		);
	}
function display_testimonial_meta_box( $testimonial ) {
// Retrieve current name of the Testimonial Author Name by Testimonial ID
    $testimonial_author = esc_html( get_post_meta( $testimonial->ID, 'testimonial_author', true ) );
    ?>
    <table>
        <tr>
            <td style="width: 100%">Author Name</td>
            <td><input type="text" size="80" name="testimonial_author_name" value="<?php echo $testimonial_author; ?>" /></td>
        </tr>
       </table>
    <?php
}
add_action( 'save_post', 'add_testimonial_author_fields', 10, 2 );
function add_testimonial_author_fields( $testimonial_id, $testimonial ) {
    // Check post type for Testimonial Author
    if ( $testimonial->post_type == 'testimonials' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['testimonial_author_name'] ) && $_POST['testimonial_author_name'] != '' ) {
            update_post_meta( $testimonial_id, 'testimonial_author', $_POST['testimonial_author_name'] );
        }
        
    }
}
?>