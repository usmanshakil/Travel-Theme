//////////////////////////////////////////////////////////////////
// Add Testimonials Shortcode
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.testimonials', {

        init : function(ed, url){
            ed.addButton('testimonials', {
                title : 'Testimonials',
                onclick : function() {
                    ed.selection.setContent('[testimonials limit="Enter Numeric Value"]');
                },
                image: url + "/testimonials.png"
            });
        }
    });
    tinymce.PluginManager.add('testimonials', tinymce.plugins.testimonials);
})();
