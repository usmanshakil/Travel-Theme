/*--------------------------------------------------------
Quote rotator
--------------------------------------------------------*/	
jQuery(document).ready(function() {
jQuery('#testimonials ul').quote_rotator({
                buttons: { next: 'Next', previous: 'Previous' }
            });
							 });