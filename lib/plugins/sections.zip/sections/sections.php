<?php
/*
Plugin Name: Page Sections
Plugin URI: http://iintellect.co.uk/
Description: Bed & Breakfast Section Plugin is used to create page section for only onepage layout of the theme.
Version: 1.0
Author: HBK
Author URI: http://iintellect.co.uk/
License: GPLv2
*/
function bbreakfast_secScripts(){
    // Register JavaScript.
    wp_register_script('jquery.scrollTo', plugins_url('js/jquery.scrollTo.js', __FILE__), array('jquery'));
	wp_register_script('jquery.nav', plugins_url('js/jquery.nav.js', __FILE__), array('jquery'));
    // Enqueue JavaScript.
    wp_enqueue_script('jquery.scrollTo');
	wp_enqueue_script('jquery.nav');}
add_action('wp_enqueue_scripts','bbreakfast_secScripts');
add_action( 'init', 'bbreakfast_sections' );
function bbreakfast_sections() {
    register_post_type( 'sections',
        array(
            'labels' => array(
                'name' => 'Page Sections',
                'singular_name' => 'Page Section',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New New Page Section',
                'edit' => 'Edit',
                'edit_item' => 'Edit Page Section',
                'new_item' => 'New Page Section',
                'view' => 'View',
                'view_item' => 'View Page Section',
                'search_items' => 'Search Page Sections',
                'not_found' => 'No Page Sections found',
                'not_found_in_trash' => 'No Page Sections found in Trash',
                'parent' => 'Parent Page Section'
            ),
 
            'public' => true,
            'menu_position' => 18,
            'supports' => array( 'title','thumbnail' ),
            'taxonomies' => array( '' ),
            'menu_icon' => plugins_url( 'images/sections.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
//Registering the Custom Function
add_action( 'admin_init', 'bb_section_meta_box' );
//Implementation of the Custom Function
function bb_section_meta_box() {
    add_meta_box( 'sections_meta_box',
        'Page Sections Details',
        'display_section_meta_box',
        'sections', 'normal', 'high'
    );
}
//Implementation of the display_Sections_meta_box Function
function display_section_meta_box( $section ) {
    // Retrieve current name  based on ID
    $page_section = intval( get_post_meta( $section->ID, 'page_section', true ) );
    $page_menu = esc_html( get_post_meta( $section->ID, 'page_menu', true ) );
    $page_title = esc_html( get_post_meta( $section->ID, 'page_title', true ) );
    $page_title_desc = esc_html( get_post_meta( $section->ID, 'page_title_desc', true ) );
    $last_section = esc_html( get_post_meta( $section->ID, 'last_section', true ) );
    $external_link = esc_html( get_post_meta( $section->ID, 'external_link', true ) );
    ?>
    <table>
          <tr>
            <td style="width: 150px">Select your Page</td>
            <td>
                <select style="width: 200px" name="page_section">
                <option value="">Choose Your Page</option>
                <?php
                  $page_name = get_page_by_title( 'home' );
                  $args = array(
                        'exclude' => $page_name->ID
                        );
                    $pages = get_pages($args);
				// Generate all items of drop-down list
				foreach ( $pages as $page ) {
                ?>
                    <option value="<?php echo $page->ID; ?>" <?php echo selected( $page->ID, $page_section ); ?>>
                    <?php echo $page->post_title; } ?>
                </select>
            </td>
        </tr>
        <tr>
            <td style="width: 150px">Active as Menu Item:</td>
            <td>
                <select style="width: 200px" name="page_menu">
                    <option value="Yes" <?php echo selected( 'Yes', $page_menu ); ?>>Yes
                    <option value="No" <?php echo selected( 'No', $page_menu ); ?>>No
                </select>
            </td>
        </tr>
        <tr>
            <td style="width: 150px">Show Section Title:</td>
            <td>
                <select style="width: 200px" name="page_title">
                    <option value="Yes" <?php echo selected( 'Yes', $page_title ); ?>>Yes
                    <option value="No" <?php echo selected( 'No', $page_title ); ?>>No
                </select>
            </td>
        </tr>
        <tr>
            <td style="width: 100%">Text Below The Title</td>
            <td><input type="text" size="80" name="page_title_desc" placeholder="A short description of the place and the accommodation" value="<?php echo $page_title_desc; ?>" /></td>
        </tr>
        <tr>
            <td style="width: 150px">Enabled As Last Section<br/><small>*Recommended for Google Map only</small></td>
            <td>
                <select style="width: 200px" name="last_section">
                    <option value="No" <?php echo selected( 'No', $last_section ); ?>>No
                    <option value="Yes" <?php echo selected( 'Yes', $last_section ); ?>>Yes
                </select>
            </td>
        </tr>
        <tr>
            <td style="width: 100%">External Link TO The Menu Item<br/><small>*This will override all above field values</td>
            <td><input type="text" size="80" name="external_link" placeholder="e.g http://somewhere.com/" value="<?php echo $external_link; ?>" /></td>
        </tr>
    </table>
    <?php
}
//Registering a Save Post Function
add_action( 'save_post', 'add_sections_fields', 10, 2 );
function add_sections_fields( $sections_id, $section ) {
    // Check post type for movie reviews
    if ( $section->post_type == 'sections' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['page_section'] ) && $_POST['page_section'] != '' ) {
            update_post_meta( $sections_id, 'page_section', $_POST['page_section'] );
        }
        if ( isset( $_POST['page_menu'] ) && $_POST['page_menu'] != '' ) {
            update_post_meta( $sections_id, 'page_menu', $_POST['page_menu'] );
        }
        if ( isset( $_POST['page_title'] ) && $_POST['page_title'] != '' ) {
            update_post_meta( $sections_id, 'page_title', $_POST['page_title'] );
        }
        if ( isset( $_POST['page_title_desc'] )) {
            update_post_meta( $sections_id, 'page_title_desc', $_POST['page_title_desc'] );
        }
        if ( isset( $_POST['last_section'] )) {
            update_post_meta( $sections_id, 'last_section', $_POST['last_section'] );
        }
        if ( isset( $_POST['external_link'] )) {
            update_post_meta( $sections_id, 'external_link', $_POST['external_link'] );
        }
    }
}
?>