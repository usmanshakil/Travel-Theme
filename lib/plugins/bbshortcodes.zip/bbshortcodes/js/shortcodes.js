//////////////////////////////////////////////////////////////////
// Add Double line Divider
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.hr', {
        init : function(ed, url){
            ed.addButton('hr', {
                title : 'Double line Divider',
                onclick : function() {
                    ed.selection.setContent('[dblline]');
                },
                image: url + "/hr.png"
            });
        }
    });
    tinymce.PluginManager.add('hr', tinymce.plugins.hr);
})();
//////////////////////////////////////////////////////////////////
// Add Info Boxes
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.info', {
        init : function(ed, url){
            ed.addButton('info', {
                title : 'Info Boxes',
                onclick : function() {
                    ed.selection.setContent('[infoboxes infoclass="add-info,payments,rules" infotitle="Addtional info"] Your Text Here[/infoboxes]</article>');
                },
                image: url + "/info.png"
            });
        }
    });
    tinymce.PluginManager.add('info', tinymce.plugins.info);
})();
//////////////////////////////////////////////////////////////////
// Add List Style 3
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.l3', {
        init : function(ed, url){
            ed.addButton('l3', {
                title : 'List Style 3',
                onclick : function() {
                    ed.selection.setContent('[list3]<li><strong>Voluptatem</strong> doloremque lauda .</li><li><strong>Voluptatem</strong> voluptatem accusantium.</li>[/list3]');
                },
                image: url + "/l3.png"
            });
        }
    });
    tinymce.PluginManager.add('l3', tinymce.plugins.l3);
})();
//////////////////////////////////////////////////////////////////
// Add Pricing Table
//////////////////////////////////////////////////////////////////
/*
(function() {
    tinymce.create('tinymce.plugins.pt', {
        init : function(ed, url){
            ed.addButton('pt', {
                title : 'Pricing Table',
                onclick : function() {
                    ed.selection.setContent('[pritab]<thead><tr><th>Room Type</th><th>Low <br/>from 23/03 to 31/05</th><th>Middle <br/>from 23/03 to 31/05</th><th>High <br/>from 23/03 to 31/05</th></thead><tbody><tr><td>Gardenia</td><td>99$</td><td>130$</td><td>199$</td></tr></tbody>[/pritab]');
                },
                image: url + "/pt.png"
            });
        }
    });
    tinymce.PluginManager.add('pt', tinymce.plugins.pt);
})();*/
//////////////////////////////////////////////////////////////////
// 1/2 Columns
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.onetwo', {
        init : function(ed, url){
            ed.addButton('onetwo', {
                title : 'One Two Columns',
                onclick : function() {
                    ed.selection.setContent('[one_half_column]...[/one_half_column]');
                },
                image: url + "/onetwo.png"
            });
        }
    });
    tinymce.PluginManager.add('onetwo', tinymce.plugins.onetwo);
})();
//////////////////////////////////////////////////////////////////
// 1/4 Columns
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.onefour', {
        init : function(ed, url){
            ed.addButton('onefour', {
                title : 'One Four Columns',
                onclick : function() {
                    ed.selection.setContent('[one_fourth_column]...[/one_fourth_column]');
                },
                image: url + "/onefour.png"
            });
        }
    });
    tinymce.PluginManager.add('onefour', tinymce.plugins.onefour);
})();
//////////////////////////////////////////////////////////////////
// 3/4 Columns
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.threefour', {
        init : function(ed, url){
            ed.addButton('threefour', {
                title : 'Three Four Columns',
                onclick : function() {
                    ed.selection.setContent('[three_four_column]...[/three_four_column]');
                },
                image: url + "/threefour.png"
            });
        }
    });
    tinymce.PluginManager.add('threefour', tinymce.plugins.threefour);
})();
//////////////////////////////////////////////////////////////////
// 1/3 Columns
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.onethree', {
        init : function(ed, url){
            ed.addButton('onethree', {
                title : 'One Three Columns',
                onclick : function() {
                    ed.selection.setContent('[one_three_column]...[/one_three_column]');
                },
                image: url + "/onethree.png"
            });
        }
    });
    tinymce.PluginManager.add('onethree', tinymce.plugins.onethree);
})();
//////////////////////////////////////////////////////////////////
// 2/3 Columns
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.twothree', {
        init : function(ed, url){
            ed.addButton('twothree', {
                title : 'Two Three Columns',
                onclick : function() {
                    ed.selection.setContent('[two_three_column]...[/two_three_column]');
                },
                image: url + "/twothree.png"
            });
        }
    });
    tinymce.PluginManager.add('twothree', tinymce.plugins.twothree);
})();
//////////////////////////////////////////////////////////////////
// Simple Title
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.st', {
        init : function(ed, url){
            ed.addButton('st', {
                title : 'Simple Title',
                onclick : function() {
                    ed.selection.setContent('[s_title]Description <span>of the accommodation</span>[/s_title]');
                },
                image: url + "/st.png"
            });
        }
    });
    tinymce.PluginManager.add('st', tinymce.plugins.st);
})();
//////////////////////////////////////////////////////////////////
// Section Title 3
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.sect', {
        init : function(ed, url){
            ed.addButton('sect', {
                title : 'Section Title 3',
                onclick : function() {
                    ed.selection.setContent('[sec_title3 t3head="Tours available"]A short description of the place and the accommodation[/sec_title3]');
                },
                image: url + "/sect.png"
            });
        }
    });
    tinymce.PluginManager.add('sect', tinymce.plugins.sect);
})();
//////////////////////////////////////////////////////////////////
// Weather
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.weather', {
        init : function(ed, url){
            ed.addButton('weather', {
                title : 'Weather',
                onclick : function() {
                    ed.selection.setContent('[weather]');
                },
                image: url + "/weather.png"
            });
        }
    });
    tinymce.PluginManager.add('weather', tinymce.plugins.weather);
})();
//////////////////////////////////////////////////////////////////
// Top Scroll Icon
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.tsi', {
        init : function(ed, url){
            ed.addButton('tsi', {
                title : 'Top Scroll Icon',
                onclick : function() {
                    ed.selection.setContent('[topscroll scrollId="You Section Name"]');
                },
                image: url + "/tsi.png"
            });
        }
    });
    tinymce.PluginManager.add('tsi', tinymce.plugins.tsi);
})();
//////////////////////////////////////////////////////////////////
// Top Border
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.tb', {
        init : function(ed, url){
            ed.addButton('tb', {
                title : 'Top Border',
                onclick : function() {
                    ed.selection.setContent('[topborder]');
                },
                image: url + "/tb.png"
            });
        }
    });
    tinymce.PluginManager.add('tb', tinymce.plugins.tb);
})();
//////////////////////////////////////////////////////////////////
// Section Title 2
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.st2', {
        init : function(ed, url){
            ed.addButton('st2', {
                title : 'Section Title 2',
                onclick : function() {
                    ed.selection.setContent('[sec_title2 t2head="Title 2"]');
                },
                image: url + "/st2.png"
            });
        }
    });
    tinymce.PluginManager.add('st2', tinymce.plugins.st2);
})();
//////////////////////////////////////////////////////////////////
// Accordion
//////////////////////////////////////////////////////////////////
/*
(function() {
    tinymce.create('tinymce.plugins.accordion', {
        init : function(ed, url){
            ed.addButton('accordion', {
                title : 'Accordion',
                onclick : function() {
                    ed.selection.setContent('[accordion acctitle="Museums tour"]<dt><a href="#">Louvre Museum - 10.00 AM</a></dt> <dd>Legimus volumus qui in, usu unum adhuc debitis no, ius sumo zril id. </dd><dt><a href="#">Tour Eiffel - 14.00 PM</a></dt><dd>Legimus volumus qui in, usu unum adhuc debitis no, ius sumo zril id. </dd><dt><a href="#">Mont Parnasse - 16.00 PM</a></dt><dd>Legimus volumus qui in, usu unum adhuc debitis no, ius sumo zril id. </dd><dt><a href="#">Impressionist Museum - 18.00 PM</a></dt><dd>Legimus volumus qui in, usu unum adhuc debitis no, ius sumo zril id. </dd>[/accordion]');
                },
                image: url + "/accordion.png"
            });
        }
    });
    tinymce.PluginManager.add('accordion', tinymce.plugins.accordion);
})();*/
//////////////////////////////////////////////////////////////////
// Activities
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.act', {
        init : function(ed, url){
            ed.addButton('act', {
                title : 'Activities',
                onclick : function() {
                    ed.selection.setContent('[activities catid="Enter Category Id"]');
                },
                image: url + "/act.png"
            });
        }
    });
    tinymce.PluginManager.add('act', tinymce.plugins.act);
})();
//////////////////////////////////////////////////////////////////
// Social Icons
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.si', {
        init : function(ed, url){
            ed.addButton('si', {
                title : 'Social Icons',
                onclick : function() {
                    ed.selection.setContent('[socialicons]<li class="facebook"><a href="#">facebook</a></li><li class="googleplus"><a href="#">googleplus</a></li><li class="twitter"><a href="#">twitter</a></li><li class="vimeo"><a href="#">vimeo</a></li><li class="youtube"><a href="#">youtube</a></li><li class="pinterest"><a href="#">pinterest</a></li><li class="skype"><a href="#">skype</a></li><li class="rss"><a href="#">rss</a></li><li class="linkedin"><a href="#">linkedin</a></li>[/socialicons]');
                },
                image: url + "/si.png"
            });
        }
    });
    tinymce.PluginManager.add('si', tinymce.plugins.si);
})();
//////////////////////////////////////////////////////////////////
// Get Direction
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.gd', {
        init : function(ed, url){
            ed.addButton('gd', {
                title : 'Get Direction',
                onclick : function() {
                    ed.selection.setContent('[getdirection dirtitle="Get Directions Title"]');
                },
                image: url + "/gd.png"
            });
        }
    });
    tinymce.PluginManager.add('gd', tinymce.plugins.gd);
})();
//////////////////////////////////////////////////////////////////
// Facilities
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.fc', {
        init : function(ed, url){
            ed.addButton('fc', {
                title : 'Facilities',
                onclick : function() {
                    ed.selection.setContent('[facility1 fctitle="Swimming Poll" fclink="#"] [facility2 fctitle="Plasma cable tv" fclink="#"] [facility3 fctitle="Breakfast" fclink="#"] [facility4 fctitle="Restaurant" fclink="#"]');
                },
                image: url + "/fc.png"
            });
        }
    });
    tinymce.PluginManager.add('fc', tinymce.plugins.fc);
})();
//////////////////////////////////////////////////////////////////
// Google Map
//////////////////////////////////////////////////////////////////
(function() {
    tinymce.create('tinymce.plugins.gm', {
        init : function(ed, url){
            ed.addButton('gm', {
                title : 'Google Map',
                onclick : function() {
                    ed.selection.setContent('[gmap]');
                },
                image: url + "/gm.png"
            });
        }
    });
    tinymce.PluginManager.add('gm', tinymce.plugins.gm);
})();
