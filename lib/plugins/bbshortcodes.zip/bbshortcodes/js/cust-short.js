jQuery(document).ready(function() {
/*--------------------------------------------------------
Weather
--------------------------------------------------------*/	  
jQuery('#weather').weatherfeed([weather], {
		forecast: true
	});
});