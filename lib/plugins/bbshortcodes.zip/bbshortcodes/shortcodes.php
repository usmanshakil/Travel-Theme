<?php
/*
Plugin Name: Bed & Breakfast Shortcodes
Plugin URI: http://iintellect.co.uk/
Description: Bed & Breakfast shortcodes provides an easy to use mechanism for creating and using custom shortcodes.
Version: 1.0
Author: HBK
Author URI: http://iintellect.co.uk/
License: GPLv2
*/
function bbreakfast_shortScripts(){
    // Register JavaScript.
    wp_register_script('jquery.zweatherfeed', plugins_url('js/jquery.zweatherfeed.js', __FILE__), array('jquery'));
	wp_register_script('cust-short', plugins_url('js/cust-short.js', __FILE__), array('jquery'));
	// Enqueue JavaScript.
	wp_enqueue_script('cust-short');
    wp_enqueue_script('jquery.zweatherfeed');}
add_action('wp_enqueue_scripts','bbreakfast_shortScripts');	
// Content filter used ONLY on custom theme shortcodes to remove
add_filter("the_content", "the_content_filter");
function the_content_filter($content) {
 // array of custom shortcodes requiring the fix
$block = join("|",array("dblline",
						"infoboxes",
						"list3",
						"pritab",
						"one_half_column",
						"three_four_column",
						"one_three_column",
						"two_three_column",
						"one_fourth_column",
						"s_title",
						"sec_title",
						"weather",
						"topscroll",
						"topborder",
						"sec_title2",
						"sec_title3",
						"accordion",
						"activities",
						"socialicons",
						"getdirection",
						"facility1",
						"facility2",
						"facility3",
						"facility4",
						"gmap"
						));

// opening tag
$rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
// closing tag
$rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
 return $rep;
 }
//simple double Line divider
add_filter('mce_external_plugins', "hr_register");
add_filter('mce_buttons', 'hr_add_button', 0);
function hr_add_button($buttons)
{
    array_push($buttons, "", "hr");
    return $buttons;
}
function hr_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['hr'] = $url;
    return $plugin_array;
}
function dblline( $atts ){
    return '<hr>';
}
add_shortcode( 'dblline', 'dblline' );
//Info Boxes
add_filter('mce_external_plugins', "info_register");
add_filter('mce_buttons', 'info_add_button', 0);
function info_add_button($buttons)
{
    array_push($buttons, "", "info");
    return $buttons;
}
function info_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['info'] = $url;
    return $plugin_array;
}
function info_boxes( $atts,$content ) {
    extract( shortcode_atts( array(
        'infoclass' => 'add-info',
        'infotitle' => 'Pass Your Title',
        ), $atts ) );
    !empty($content) ? $content : 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium';
return "<div class='info-box'>
    	<h4 class='".$atts['infoclass']."'>".$atts['infotitle']."</h4>
        ".do_shortcode($content)."
      </div>";
}
add_shortcode( 'infoboxes', 'info_boxes' );
// List Style Three
add_filter('mce_external_plugins', "l3_register");
add_filter('mce_buttons', 'l3_add_button', 0);
function l3_add_button($buttons)
{
    array_push($buttons, "", "l3");
    return $buttons;
}
function l3_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['l3'] = $url;
    return $plugin_array;
}
function liststyle_three($atts,$content){
    extract( shortcode_atts( array(
        'ulclass' => 'add-list_3',
        ), $atts ) );
    return "<ul class='list_3'>
    ".$content."
    </ul>";
}
add_shortcode( 'list3', 'liststyle_three' );
//Pricing Table
add_filter('mce_external_plugins', "pt_register");
add_filter('mce_buttons', 'pt_add_button', 0);
function pt_add_button($buttons)
{
    array_push($buttons, "", "pt");
    return $buttons;
}
function pt_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['pt'] = $url;
    return $plugin_array;
}
function pricing_table($atts,$content){
    extract( shortcode_atts( array(
        'tblid' => 'rates',
    ), $atts ) );
    return "<div class='add-bottom_3' id='rates'>"
      .$content.
    "</div>";
}
add_shortcode( 'pritab', 'pricing_table' );
// 1/2 column
add_filter('mce_external_plugins', "onetwo_register");
add_filter('mce_buttons_3', 'onetwo_add_button', 0);
function onetwo_add_button($buttons)
{
    array_push($buttons, "", "onetwo");
    return $buttons;
}
function onetwo_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['onetwo'] = $url;
    return $plugin_array;
}
function one_half( $atts, $content = null ) {
    return '<div class="eight columns">' . do_shortcode($content) . '</div>';
}
add_shortcode( 'one_half_column', 'one_half' );
// 1/4 column
add_filter('mce_external_plugins', "onefour_register");
add_filter('mce_buttons_3', 'onefour_add_button', 0);
function onefour_add_button($buttons)
{
    array_push($buttons, "", "onefour");
    return $buttons;
}
function onefour_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['onefour'] = $url;
    return $plugin_array;
}
function one_four( $atts, $content = null ) {
    return '<div class="four columns">' . do_shortcode($content) . '</div>';
}
add_shortcode( 'one_fourth_column', 'one_four' );
// 3/4 Columns
add_filter('mce_external_plugins', "threefour_register");
add_filter('mce_buttons_3', 'threefour_add_button', 0);
function threefour_add_button($buttons)
{
    array_push($buttons, "", "threefour");
    return $buttons;
}
function threefour_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['threefour'] = $url;
    return $plugin_array;
}
function three_four( $atts, $content = null ) {
    return '<div class="twelve columns">'. do_shortcode($content) . '</div>';
}
add_shortcode( 'three_four_column', 'three_four' );
// 1/3 Columns
add_filter('mce_external_plugins', "onethree_register");
add_filter('mce_buttons_3', 'onethree_add_button', 0);
function onethree_add_button($buttons)
{
    array_push($buttons, "", "onethree");
    return $buttons;
}
function onethree_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['onethree'] = $url;
    return $plugin_array;
}
function one_three( $atts, $content = null ) {
    return '<div class="one-third column">' . do_shortcode($content) . '</div>';
}
add_shortcode( 'one_three_column', 'one_three' );
// 2/3 Columns
add_filter('mce_external_plugins', "twothree_register");
add_filter('mce_buttons_3', 'twothree_add_button', 0);
function twothree_add_button($buttons)
{
    array_push($buttons, "", "twothree");
    return $buttons;
}
function twothree_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['twothree'] = $url;
    return $plugin_array;
}
function two_three( $atts, $content = null ) {
    return '<div class="two-thirds column">' . do_shortcode($content) . '</div>';
}
add_shortcode( 'two_three_column', 'two_three' );
// Simple title
add_filter('mce_external_plugins', "st_register");
add_filter('mce_buttons_3', 'st_add_button', 0);
function st_add_button($buttons)
{
    array_push($buttons, "", "st");
    return $buttons;
}
function st_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['st'] = $url;
    return $plugin_array;
}
function simple_title( $atts, $content = null ) {
    return '<h3>' . $content . '</h3>';
}
add_shortcode( 's_title', 'simple_title' );
// Section Title
function section_title($atts,$content){
    extract( shortcode_atts( array(
        'thead' => 'Title Heading',
    ), $atts ) );
    return "<div class='section-title-3'>
     <h3>".$atts['thead']."</h3>"
      .$content.
    "</div>";
}
add_shortcode( 'sec_title', 'section_title' );
// Weather
add_filter('mce_external_plugins', "weather_register");
add_filter('mce_buttons', 'weather_add_button', 0);
function weather_add_button($buttons)
{
    array_push($buttons, "", "weather");
    return $buttons;
}
function weather_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['weather'] = $url;
    return $plugin_array;
}
function weather( $atts) {
    return "<div id='weather' class='clearfix'></div>";
}
add_shortcode( 'weather', 'weather' );
//Top Scroll Icon
add_filter('mce_external_plugins', "tsi_register");
add_filter('mce_buttons', 'tsi_add_button', 0);
function tsi_add_button($buttons)
{
    array_push($buttons, "", "tsi");
    return $buttons;
}
function tsi_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['tsi'] = $url;
    return $plugin_array;
}
function top_scroll($atts,$content){
    extract( shortcode_atts( array(
        'scrollid' => 'home',
    ), $atts ) );
    return "<a href='#".$atts['scrollid']."' class='scroll_a'> Back to top</a>";
}
add_shortcode( 'topscroll', 'top_scroll' );
//Section Top Border
add_filter('mce_external_plugins', "tb_register");
add_filter('mce_buttons', 'tb_add_button', 0);
function tb_add_button($buttons)
{
    array_push($buttons, "", "tb");
    return $buttons;
}
function tb_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['tb'] = $url;
    return $plugin_array;
}
function topborder( $atts ){
    return "<span class='border-top'></span>";
}
add_shortcode( 'topborder', 'topborder' );
//Section Title Two
add_filter('mce_external_plugins', "st2_register");
add_filter('mce_buttons_3', 'st2_add_button', 0);
function st2_add_button($buttons)
{
    array_push($buttons, "", "st2");
    return $buttons;
}
function st2_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['st2'] = $url;
    return $plugin_array;
}
function section_title2($atts,$content){
    extract( shortcode_atts( array(
        't2head' => 'Title2 Heading',
    ), $atts ) );
    return "<div class='section-title'>
      <h2>".$atts['t2head']."</h2>
      <p>".$content."</p>
    </div>";
}
add_shortcode( 'sec_title2', 'section_title2' );
//Section Title Three
add_filter('mce_external_plugins', "sect_register");
add_filter('mce_buttons_3', 'sect_add_button', 0);
function sect_add_button($buttons)
{
    array_push($buttons, "", "sect");
    return $buttons;
}
function sect_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['sect'] = $url;
    return $plugin_array;
}
function section_title3($atts,$content){
    extract( shortcode_atts( array(
        't3head' => 'Title3 Heading',
    ), $atts ) );
    return "<div class='section-title-3'>
      <h3>".$atts['t3head']."</h3>
      <p>".$content."</p>
    </div>";
}
add_shortcode( 'sec_title3', 'section_title3' );
// Accordion
add_filter('mce_external_plugins', "accordion_register");
add_filter('mce_buttons_3', 'accordion_add_button', 0);
function accordion_add_button($buttons)
{
    array_push($buttons, "", "accordion");
    return $buttons;
}
function accordion_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['accordion'] = $url;
    return $plugin_array;
}
function accordion($atts,$content){
    extract( shortcode_atts( array(
        'acctitle' => 'Accordion Title',
    ), $atts ) );
    return "<h4 class='tours'>".$atts['acctitle']."</h4>
      <dl class='accordion'>
       ".$content."
      </dl>";
}
add_shortcode( 'accordion', 'accordion' );
//Activities
add_filter('mce_external_plugins', "act_register");
add_filter('mce_buttons_3', 'act_add_button', 0);
function act_add_button($buttons)
{
    array_push($buttons, "", "act");
    return $buttons;
}
function act_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['act'] = $url;
    return $plugin_array;
}
function activities($atts){
    extract( shortcode_atts( array(
        'catid' => 1,
    ), $atts ) );
    global $post;
    query_posts("cat=".$atts['catid']."&showposts=3");
    while (have_posts()) : the_post(); ?>
            <article class="one-third column" id="activities">
            <figure><span></span><?php the_post_thumbnail();?> </figure>
            <h3><?php the_title(); ?></h3>
            <?php the_excerpt();?>
            <a href="<?php the_permalink();?>" class="button_3"><?php _e('read more',TEXTDOMAIN); ?></a>
        </article>
    <?php endwhile;
}
add_shortcode( 'activities', 'activities' );
// Social Icons
add_filter('mce_external_plugins', "si_register");
add_filter('mce_buttons', 'si_add_button', 0);
function si_add_button($buttons)
{
    array_push($buttons, "", "si");
    return $buttons;
}
function si_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['si'] = $url;
    return $plugin_array;
}
function social_icons($atts,$content){
    extract( shortcode_atts( array(
        'socio' => 'Accordion Title',
    ), $atts ) );
    return "<ul class='social-bookmarks clearfix'>"
        .$content.
        "</ul>";
}
add_shortcode( 'socialicons', 'social_icons' );
//Get Direction
add_filter('mce_external_plugins', "gd_register");
add_filter('mce_buttons', 'gd_add_button', 0);
function gd_add_button($buttons)
{
    array_push($buttons, "", "gd");
    return $buttons;
}
function gd_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['gd'] = $url;
    return $plugin_array;
}
function get_direction($atts,$content){
    $fk =  __( 'Get Directions', TEXTDOMAIN );
    $fk1 =  __( 'Ex: Las Palmas de Gran Canaria Airport', TEXTDOMAIN );
    $fk2 =  __( 'Enter your location', TEXTDOMAIN );
    extract( shortcode_atts( array(
        'dirtitle' => 'Get directions',
    ), $atts ) );
    $btn = "<h4 id='directions'>".$atts['dirtitle']."<span>(".$fk1.")</span></h4>
        <form action='http://maps.google.com/maps' method='get' target='_blank'>
  	 		<input type='text' name='saddr'  placeholder='".$fk2."'/>
   			<input type='submit' value='".$fk."' class='button_4' />
		</form>";
    return $btn;
}
add_shortcode( 'getdirection', 'get_direction' );
//Main Facilities
add_filter('mce_external_plugins', "fc_register");
add_filter('mce_buttons', 'fc_add_button', 0);
function fc_add_button($buttons)
{
    array_push($buttons, "", "fc");
    return $buttons;
}
function fc_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['fc'] = $url;
    return $plugin_array;
}
function main_facility1($atts,$content){
    extract( shortcode_atts( array(
        'fctitle' => 'Swimming poll',
        'fclink' => '#',
    ), $atts ) );
    return "<div class='four columns'><span>
    <a href='".$atts['fclink']."'><img src='".plugins_url( 'images/facilities-1.png', __FILE__ )."' alt='' class='scale-with-grid' >
    </a></span>
    <h4>".$atts['fctitle']."</h4>
    </div>";
}
add_shortcode( 'facility1', 'main_facility1' );
function main_facility2($atts,$content){
    extract( shortcode_atts( array(
        'fctitle' => 'Plasma cable tv',
        'fclink' => '#',
    ), $atts ) );
    return "<div class='four columns'><span>
    <a href='".$atts['fclink']."'><img src='".plugins_url( 'images/facilities-2.png', __FILE__ )."' alt='' class='scale-with-grid' >
    </a></span>
    <h4>".$atts['fctitle']."</h4>
    </div>";
}
add_shortcode( 'facility2', 'main_facility2' );
function main_facility3($atts,$content){
    extract( shortcode_atts( array(
        'fctitle' => 'Breakfast',
        'fclink' => '#',
    ), $atts ) );
    return "<div class='four columns'><span>
    <a href='".$atts['fclink']."'><img src='".plugins_url( 'images/facilities-3.png', __FILE__ )."' alt='' class='scale-with-grid' >
    </a></span>
    <h4>".$atts['fctitle']."</h4>
    </div>";
}
add_shortcode( 'facility3', 'main_facility3' );
function main_facility4($atts,$content){
    extract( shortcode_atts( array(
        'fctitle' => 'Restaurant',
        'fclink' => '#',
    ), $atts ) );
    return "<div class='four columns'><span>
    <a href='".$atts['fclink']."'><img src='".plugins_url( 'images/facilities-4.png', __FILE__ )."' alt='' class='scale-with-grid' >
    </a></span>
    <h4>".$atts['fctitle']."</h4>
    </div>";
}
add_shortcode( 'facility4', 'main_facility4' );
//Google Map
add_filter('mce_external_plugins', "gm_register");
add_filter('mce_buttons', 'gm_add_button', 0);
function gm_add_button($buttons)
{
    array_push($buttons, "", "gm");
    return $buttons;
}
function gm_register($plugin_array)
{
    $url = trim(get_bloginfo('url'), "/")."/wp-content/plugins/bbshortcodes/js/shortcodes.js";
    $plugin_array['gm'] = $url;
    return $plugin_array;
}
function google_map($atts){
    return "<div id='map'></div>";
}
add_shortcode( 'gmap', 'google_map' );